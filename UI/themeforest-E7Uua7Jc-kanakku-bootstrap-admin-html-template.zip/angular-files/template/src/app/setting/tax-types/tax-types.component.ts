import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tax-types',
  templateUrl: './tax-types.component.html',
  styleUrls: ['./tax-types.component.css']
})
export class TaxTypesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
