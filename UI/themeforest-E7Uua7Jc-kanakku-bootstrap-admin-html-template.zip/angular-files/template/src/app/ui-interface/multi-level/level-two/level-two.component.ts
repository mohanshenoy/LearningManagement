import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-level-two',
  templateUrl: './level-two.component.html',
  styleUrls: ['./level-two.component.css']
})
export class LevelTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
