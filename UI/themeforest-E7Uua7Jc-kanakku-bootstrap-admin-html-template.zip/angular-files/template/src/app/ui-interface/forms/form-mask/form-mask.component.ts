import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-form-mask',
  templateUrl: './form-mask.component.html',
  styleUrls: ['./form-mask.component.css']
})
export class FormMaskComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
