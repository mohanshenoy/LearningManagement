import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-horizondal-form',
  templateUrl: './horizondal-form.component.html',
  styleUrls: ['./horizondal-form.component.css']
})
export class HorizondalFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
