import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regiser',
  templateUrl: './regiser.component.html',
  styleUrls: ['./regiser.component.css']
})
export class RegiserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
