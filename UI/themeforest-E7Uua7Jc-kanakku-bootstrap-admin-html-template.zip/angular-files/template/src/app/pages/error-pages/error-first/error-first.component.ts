import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-first',
  templateUrl: './error-first.component.html',
  styleUrls: ['./error-first.component.css']
})
export class ErrorFirstComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
