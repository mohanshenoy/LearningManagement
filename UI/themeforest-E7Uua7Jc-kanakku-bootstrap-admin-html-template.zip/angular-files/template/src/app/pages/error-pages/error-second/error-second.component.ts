import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-second',
  templateUrl: './error-second.component.html',
  styleUrls: ['./error-second.component.css']
})
export class ErrorSecondComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
