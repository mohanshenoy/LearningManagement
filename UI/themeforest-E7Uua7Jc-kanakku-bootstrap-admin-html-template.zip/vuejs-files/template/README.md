# kanakku-vuejs

This is Vue 3 version

## Includes

- Vue 3.1.5
- Vue Router 4.0.0-beta.1
- Vuex 4.0.0-beta.4
- Babel 7.10.4
- Webpack 4.43.0


## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run dev
```

### Compiles and minifies for production
```
npm run build
```

