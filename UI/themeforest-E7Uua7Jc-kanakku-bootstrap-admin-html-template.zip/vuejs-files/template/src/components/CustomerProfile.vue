<template>
    <div class="main-wrapper">
            <layout-header></layout-header>
			<layout-sidebar></layout-sidebar>
			
			<!-- Page Wrapper -->
			<div class="page-wrapper">
				<div class="content container-fluid">
				
					<div class="row justify-content-lg-center">
						<div class="col-lg-10">
						
							<!-- Page Header -->
							<div class="page-header">
								<div class="row">
									<div class="col">
										<h3 class="page-title">Profile</h3>
										<ul class="breadcrumb">
											<li class="breadcrumb-item"><router-link to="/">Dashboard</router-link></li>
											<li class="breadcrumb-item active">Profile</li>
										</ul>
									</div>
								</div>
							</div>
							<!-- /Page Header -->
			   
							<div class="profile-cover">
								<div class="profile-cover-wrap">
									<img class="profile-cover-img" src="../assets/img/profiles/avatar-02.jpg" alt="Profile Cover">

									<!-- Custom File Cover -->
									<div class="cover-content">
										<div class="custom-file-btn">
											<input type="file" class="custom-file-btn-input" id="cover_upload">
											<label class="custom-file-btn-label btn btn-sm btn-white" for="cover_upload">
												<i class="fas fa-camera"></i>
												<span class="d-none d-sm-inline-block ms-2">Update Cover</span>
											</label>
										</div>
									</div>
									<!-- /Custom File Cover -->
								</div>
							</div>

							<div class="text-center mb-5">
								<label class="avatar avatar-xxl profile-cover-avatar" for="avatar_upload">
									<img class="avatar-img" src="../assets/img/profiles/avatar-02.jpg" alt="Profile Image">
									<input type="file" id="avatar_upload">
									<span class="avatar-edit">
										<i data-feather="edit-2" class="avatar-uploader-icon shadow-soft"></i>
									</span>
								</label>
								<h2>Charles Hafner <i class="fas fa-certificate text-primary small" data-toggle="tooltip" data-placement="top" title="" data-original-title="Verified"></i></h2>
								<ul class="list-inline">
									<li class="list-inline-item">
										<i class="far fa-building"></i> <span>Hafner Pvt Ltd.</span>
									</li>
									<li class="list-inline-item ms-1">
										<i class="fas fa-map-marker-alt"></i> West Virginia, US
									</li>
									<li class="list-inline-item ms-1">
										<i class="far fa-calendar-alt"></i> <span>Joined November 2017</span>
									</li>
								</ul>
							</div>
			
							<div class="row">
								<div class="col-lg-4">
									<div class="card card-body">
										<h5>Complete your profile</h5>

										<!-- Progress -->
										<div class="d-flex justify-content-between align-items-center">
											<div class="progress progress-md flex-grow-1">
												<div class="progress-bar bg-primary" role="progressbar" style="width: 30%" aria-valuenow="30" aria-valuemin="0" aria-valuemax="100"></div>
											</div>
											<span class="ms-4">30%</span>
										</div>
										<!-- /Progress -->
									</div>

									<div class="card">
										<div class="card-header">
											<h5 class="card-title d-flex justify-content-between">
												<span>Profile</span> 
												<router-link class="btn btn-sm btn-white" to="/settings">Edit</router-link>
											</h5>
										</div>
										<div class="card-body">
											<ul class="list-unstyled mb-0">
												<li class="py-0">
													<small class="text-dark">About</small>
												</li>
												<li>
													Charles Hafner
												</li>
												<li>
													Hafner Pvt Ltd.
												</li>
												<li class="pt-2 pb-0">
													<small class="text-dark">Contacts</small>
												</li>
												<li>
													charleshafner@example.com
												</li>
												<li>
													+1 (304) 499-13-66
												</li>
												<li class="pt-2 pb-0">
													<small class="text-dark">Address</small>
												</li>
												<li>
													4663  Agriculture Lane,<br>
													Miami,<br>
													Florida - 33165,<br>
													United States.
												</li>
											</ul>
										</div>
									</div>

								</div>

								<div class="col-lg-8">
									<div class="card">
										<div class="card-header">
											<h5 class="card-title">Activity</h5>
										</div>
										<div class="card-body card-body-height">
											<ul class="activity-feed">
												<li class="feed-item">
													<div class="feed-date">Nov 16</div>
													<span class="feed-text"><router-link to="/profile">Brian Johnson</router-link> has paid the invoice <router-link to="/view-invoice">"#DF65485"</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Nov 7</div>
													<span class="feed-text"><router-link to="/profile">Marie Canales</router-link>  has accepted your estimate <router-link to="/view-estimate">#GTR458789</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Oct 24</div>
													<span class="feed-text">New expenses added <router-link to="/expenses">"#TR018756</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Jan 27</div>
													<span class="feed-text"><router-link to="/profile">Robert Martin</router-link> gave a review for <router-link to="/product-details">"Dell Laptop"</router-link></span>
												</li>
												<li class="feed-item">
													<div class="feed-date">Jan 14</div>
													<span class="feed-text">New customer registered <router-link to="/profile">"Tori Carter"</router-link></span>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				
			</div>
			<!-- /Page Wrapper -->
			
		</div>
		<!-- /Main Wrapper -->
</template>
<script>


export default {
	components: {
		
	}
}
</script>